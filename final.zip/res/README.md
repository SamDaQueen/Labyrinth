# Labyrinth Dungeon Model & Controller

#### Samreen Reyaz Ansari

##### Programming Design Paradigm

1. **About:** The Labyrinth Dungeon Model represents a maze game where we have a player navigating through the maze. There is a start and an exit to the maze. It is a user-driven program and the user can guide the player to the exit by choosing each step of the player. There are hungry monsters known as Otyughs in the dungeon that will devour the player if the player enters their cave. Along the path, the player can collect arrows to shoot the monster as well as collect treasures to add to their score. Escape the monsters and try reaching the exit of the labyrinth.

2. **List of features**:

   - A dungeon is a grid of caves and tunnels and the grid size is provided by the user. 
   - Each cave or tunnel is connected by all other caves and tunnels by at least one path.
   - For more than a single path, we can increase the degree of connectivity between the nodes. The degree of interconnectivity for our dungeon is provided by the user.
   - A tunnel has exactly two adjacent neighbors whereas a cave can have one, three or four neighbors.
   - A player starts at a cave in the dungeon, and may move in four possible directions, if they are connected to the adjacent caves/tunnels.
   - The minimum number of steps between the starting and ending point will always be at least 5.
   - The dungeon can by wrapping or non-wrapping as required by the user. Wrapping dungeons have some edges that connect the top-bottom and left-right of the dungeon.
   - At every node, the player status and details about the location can be printed.
   - Caves can contain Otyugh monsters and treasures that give score. The percentage of caves with treasures is given by the user. The player can pick the treasure at the current position. Caves and tunnels can contain arrows that are used to kill the Otyugh. Arrows occur with the same frequency as treasure.
   - Player can use the arrows to shoot the Otyughs. Players can only hit an Otyugh if their arrow lands exactly at the Otyugh's cave. 
   - The game ends when either the player gets eaten by an Otyugh or the player reaches the exit of the labyrinth.

3. **How To Run**: 

   - The Dungeon.jar file can be found in the /res directory.
   - To run it, type "java -jar Dungeon.jar <height> <width> <interconnectivity> <isWrapping> <percentage of caves with treasure> <difficulty>" on the terminal within the directory.  For example, "java -jar Dungeon.jar 5 5 3 true 25". 
   - Height and width indicate the size of the dungeon. Interconnectivity is the number of additional paths over the minimum connectivity. isWrapping indicates whether the cave edges wrap or not. Percentage of caves with treasure is used for populating the labyrinth with treasures and arrows. Difficulty is the number of Otyughs present in the labyrinth.
   
4. **How to Use the Program**: 

   - The interactive program will ask the user for input at each step. The user can select from four options: Move, Pick, Shoot and Quit.
   - Move:
     - Enter "move <direction>" or "m <direction>" for attempting to move in that particular direction
     - <direction> can be north/south/west/east/n/s/w/e
   - Pick:
     - Enter "pick" or "p" for attempting to pick all the arrows and treasures in the current position
   - Shoot:
     - Enter "shoot <direction> <distance>" for attempting to shoot in the given direction till the given distance
     - <direction> can be north/south/west/east/n/s/w/e
     - <distance> can be a number between 1 and 5 inclusive
   - Quit:
     - Enter "quit" or "q" to exit the game

5. **Description of Example:**

   **Run -- CompleteRun.txt:**

   1. Introductory message
   2. Pick arrows and treasures
   3. Move around
   4. Try to shoot east with distance 2
   5. ...
   6. Kill Otyugh
   7. ...
   8. Reach end

   **Run -- PlayerDeadRun.txt:**

   1. Introductory message
   2. Move west
   3. Try to shoot south with distance 1
   4. ...
   5. Kill Otyugh
   6. ...
   7. Move to cave with injured Otyugh
   8. Escape
   9. Move to cave with injured Otyugh
   10. Get eaten

6. **Design/Model Changes**: 

   - Removed enum for Health of Otyugh
   - Added integer for Otyugh health
   - Removed enum for Smell in Cave
   - Removed public method for getting the smell
   - Added method to get string representation for smell

7. **Assumptions:** 

   - Moving in a cave does not mean that the treasure/arrows in it will be picked
   - User can pick treasure and arrows only from the current node
   - A player can only move to adjacent nodes
   - A player can only move one node at a time
   - A player can only move to a neighbor if there is an edge from current node to the neighbor
   - All edges are bi-directional
   - A player can stop at at tunnel
   - Arrows cannot be reclaimed
   - Extra Otyughs (more than the number of caves) are discarded
   - Player cannot fire arrow in the same cave
   - Can only shoot arrow in the directions available
   - Can only shoot between a distance of 1 to 5
   - Player cannot hit themselves
   - Stench cannot travel through walls

8. **Limitations**: 

   - Player can only view neighboring nodes
   - Dungeon of size smaller than 1 * 6 / 6 * 1 / 3 * 4 cannot be created
   - Dungeons of large sizes might take a lot of time to generate 
   - It is possible for the program to never end if the user keeps getting stuck in a loop deliberately
   - No option to pick up treasure and arrows separately

9. **Citations:** 

   - *Array of arrays in Java*. TutorialKart. (2020, November 23) from https://www.tutorialkart.com/java/java-array/array-of-arrays-in-java/. 
   - *The Map Interface*. (The Java™ Tutorials > Collections > Interfaces) from https://docs.oracle.com/javase/tutorial/collections/interfaces/map.html. 
   - *Lesson: Interfaces*. (The Java™ Tutorials > Collections) from https://docs.oracle.com/javase/tutorial/collections/interfaces/index.html. 
   - *HashMap and treemap in Java*. GeeksforGeeks. (2018, December 11) from https://www.geeksforgeeks.org/hashmap-treemap-java/. 
   - Fejér, A. *Command-line arguments in Java*. Baeldung (2020, April 27) from https://www.baeldung.com/java-command-line-arguments. 
   - Hasija, A. (2021, September 10). *Dijsktra's algorithm*. GeeksforGeeks from https://www.geeksforgeeks.org/dijkstras-shortest-path-algorithm-greedy-algo-7/. 
   - Jump, M. (n.d.). *https://northeastern.instructure.com/courses/90366/pages/module-8-mvc-controllers?module_item_id=6535605*. Canvas Northeastern. 

